#
# TABLE STRUCTURE FOR: barang
#

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(255) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  `total` int(11) NOT NULL,
  PRIMARY KEY (`id_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

INSERT INTO `barang` (`id_barang`, `nama_kategori`, `tanggal`, `total`) VALUES ('33', 'Botol', '2021-04-26', '15');
INSERT INTO `barang` (`id_barang`, `nama_kategori`, `tanggal`, `total`) VALUES ('34', 'Kardus', '2021-04-26', '5');
INSERT INTO `barang` (`id_barang`, `nama_kategori`, `tanggal`, `total`) VALUES ('35', 'Isolasi', '2021-04-26', '30');
INSERT INTO `barang` (`id_barang`, `nama_kategori`, `tanggal`, `total`) VALUES ('39', 'Stiker Hologram', '2021-05-02', '20');
INSERT INTO `barang` (`id_barang`, `nama_kategori`, `tanggal`, `total`) VALUES ('40', 'Tutup Botol', '2021-05-02', '20');
INSERT INTO `barang` (`id_barang`, `nama_kategori`, `tanggal`, `total`) VALUES ('41', 'Botol', '2021-05-02', '20');
INSERT INTO `barang` (`id_barang`, `nama_kategori`, `tanggal`, `total`) VALUES ('42', 'Kardus', '2021-05-02', '20');
INSERT INTO `barang` (`id_barang`, `nama_kategori`, `tanggal`, `total`) VALUES ('43', 'Tutup Botol', '2021-05-02', '20');
INSERT INTO `barang` (`id_barang`, `nama_kategori`, `tanggal`, `total`) VALUES ('44', 'Isolasi', '2021-05-02', '20');
INSERT INTO `barang` (`id_barang`, `nama_kategori`, `tanggal`, `total`) VALUES ('45', 'AIR', '2021-05-02', '20');


#
# TABLE STRUCTURE FOR: detail_barang
#

DROP TABLE IF EXISTS `detail_barang`;

CREATE TABLE `detail_barang` (
  `id_detailbarang` int(50) NOT NULL AUTO_INCREMENT,
  `id_pengiriman` int(255) NOT NULL,
  `nama_pengirim` varchar(255) NOT NULL,
  `nomorhp` varchar(255) NOT NULL,
  `jenis_kendaraan` varchar(255) NOT NULL,
  `tujuan` int(255) NOT NULL,
  `jumlah` int(255) NOT NULL,
  `nomor_kendaraan` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `tanngal_diterima` date NOT NULL,
  `status_pengiriman` varchar(255) NOT NULL,
  PRIMARY KEY (`id_detailbarang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: detail_pengiriman
#

DROP TABLE IF EXISTS `detail_pengiriman`;

CREATE TABLE `detail_pengiriman` (
  `id_detailpengiriman` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengiriman` int(50) NOT NULL,
  `namapengirim` varchar(255) NOT NULL,
  `no_hp` int(255) NOT NULL,
  `jeniskendaraan` varchar(255) NOT NULL,
  `tujuan_pengiriman` varchar(255) NOT NULL,
  `no_kendaraan` varchar(255) NOT NULL,
  `status` enum('Proses Pengiriman','Sudah Terkirim') NOT NULL,
  `jumlah_pengiriman` int(255) NOT NULL,
  `tanggal_masuk` date NOT NULL,
  `tanggal_diterima` date NOT NULL,
  PRIMARY KEY (`id_detailpengiriman`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `detail_pengiriman` (`id_detailpengiriman`, `id_pengiriman`, `namapengirim`, `no_hp`, `jeniskendaraan`, `tujuan_pengiriman`, `no_kendaraan`, `status`, `jumlah_pengiriman`, `tanggal_masuk`, `tanggal_diterima`) VALUES ('5', '29', 'Akbar', '855221133', 'Pickup', 'Malang', 'P2032XM', 'Sudah Terkirim', '100', '2021-04-30', '2021-05-05');


#
# TABLE STRUCTURE FOR: detail_produksi
#

DROP TABLE IF EXISTS `detail_produksi`;

CREATE TABLE `detail_produksi` (
  `id_detailproduksi` int(50) NOT NULL AUTO_INCREMENT,
  `id_produksi` int(50) NOT NULL,
  `tanggal` date NOT NULL,
  `nama_staff` varchar(50) NOT NULL,
  `shift` varchar(50) NOT NULL,
  PRIMARY KEY (`id_detailproduksi`),
  KEY `id_produk_idxfk` (`id_produksi`),
  CONSTRAINT `id_produk_idxfk` FOREIGN KEY (`id_produksi`) REFERENCES `produksi` (`id_produksi`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `detail_produksi` (`id_detailproduksi`, `id_produksi`, `tanggal`, `nama_staff`, `shift`) VALUES ('5', '35', '2021-04-30', 'zaman1s', 'shift2');


#
# TABLE STRUCTURE FOR: detail_semuabarang
#

DROP TABLE IF EXISTS `detail_semuabarang`;

CREATE TABLE `detail_semuabarang` (
  `id_detailsemuabarang` int(50) NOT NULL AUTO_INCREMENT,
  `tanggal_stockgudang` date NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `stock_pabrik` int(255) NOT NULL,
  PRIMARY KEY (`id_detailsemuabarang`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `detail_semuabarang` (`id_detailsemuabarang`, `tanggal_stockgudang`, `nama_barang`, `stock_pabrik`) VALUES ('7', '2021-05-01', 'Botol', '75');
INSERT INTO `detail_semuabarang` (`id_detailsemuabarang`, `tanggal_stockgudang`, `nama_barang`, `stock_pabrik`) VALUES ('8', '2021-05-02', 'Kardus', '40');
INSERT INTO `detail_semuabarang` (`id_detailsemuabarang`, `tanggal_stockgudang`, `nama_barang`, `stock_pabrik`) VALUES ('9', '2021-05-02', 'Isolasi', '33');
INSERT INTO `detail_semuabarang` (`id_detailsemuabarang`, `tanggal_stockgudang`, `nama_barang`, `stock_pabrik`) VALUES ('10', '2021-05-02', 'AIR', '33');
INSERT INTO `detail_semuabarang` (`id_detailsemuabarang`, `tanggal_stockgudang`, `nama_barang`, `stock_pabrik`) VALUES ('11', '2021-05-03', 'Stiker Hologram', '20');
INSERT INTO `detail_semuabarang` (`id_detailsemuabarang`, `tanggal_stockgudang`, `nama_barang`, `stock_pabrik`) VALUES ('12', '2021-05-02', 'Tutup Botol', '40');


#
# TABLE STRUCTURE FOR: detail_stockproduksi
#

DROP TABLE IF EXISTS `detail_stockproduksi`;

CREATE TABLE `detail_stockproduksi` (
  `id_detailstockproduksi` int(255) NOT NULL AUTO_INCREMENT,
  `tanggal_stockproduksi` date NOT NULL,
  `stock_produksi` int(255) NOT NULL,
  PRIMARY KEY (`id_detailstockproduksi`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `detail_stockproduksi` (`id_detailstockproduksi`, `tanggal_stockproduksi`, `stock_produksi`) VALUES ('4', '2021-04-30', '200');


#
# TABLE STRUCTURE FOR: kategori
#

DROP TABLE IF EXISTS `kategori`;

CREATE TABLE `kategori` (
  `id_kategori` int(50) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(255) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES ('7', 'Botol');
INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES ('10', 'Kardus');
INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES ('11', 'Tutup Botol');
INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES ('12', 'Isolasi');
INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES ('14', 'Stiker Hologram');


#
# TABLE STRUCTURE FOR: login
#

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `level` enum('admin','Staff Produksi','Staff Pengiriman','Staff Gudang') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `login` (`id`, `nama`, `username`, `password`, `level`) VALUES ('17', 'haris46', 'admin', 'admin', 'admin');
INSERT INTO `login` (`id`, `nama`, `username`, `password`, `level`) VALUES ('24', 'produksi', 'produksi', '1234', 'Staff Produksi');
INSERT INTO `login` (`id`, `nama`, `username`, `password`, `level`) VALUES ('25', 'pengiriman', 'pengiriman', '1234', 'Staff Pengiriman');
INSERT INTO `login` (`id`, `nama`, `username`, `password`, `level`) VALUES ('26', 'Gudang', 'gudang', '1234', 'Staff Gudang');


#
# TABLE STRUCTURE FOR: penggunaan_bahanbaku
#

DROP TABLE IF EXISTS `penggunaan_bahanbaku`;

CREATE TABLE `penggunaan_bahanbaku` (
  `id_bahanbaku` int(50) NOT NULL AUTO_INCREMENT,
  `nama_barang` varchar(255) NOT NULL,
  `jumlah_pengunaan` int(255) NOT NULL,
  PRIMARY KEY (`id_bahanbaku`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: pengiriman
#

DROP TABLE IF EXISTS `pengiriman`;

CREATE TABLE `pengiriman` (
  `id_pengiriman` int(255) NOT NULL AUTO_INCREMENT,
  `nama_pengirim` varchar(255) NOT NULL,
  `nomorhp` varchar(255) NOT NULL,
  `tujuan` varchar(255) NOT NULL,
  `jumlah` varchar(255) NOT NULL,
  `jenis_kendaraan` varchar(255) NOT NULL,
  `nomor_kendaraan` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `status_pengiriman` enum('Proses Pengiriman','Sudah Terkirim') NOT NULL,
  PRIMARY KEY (`id_pengiriman`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

INSERT INTO `pengiriman` (`id_pengiriman`, `nama_pengirim`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `status_pengiriman`) VALUES ('21', 'Haris', 'Haris', 'Malang', '4', 'Cold DIsel', 'N8192AN', '2021-04-23', 'Sudah Terkirim');
INSERT INTO `pengiriman` (`id_pengiriman`, `nama_pengirim`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `status_pengiriman`) VALUES ('23', 'Akbar', '087565211', 'Malang', '3', 'Pickup', 'P2032XM', '2021-04-25', 'Sudah Terkirim');
INSERT INTO `pengiriman` (`id_pengiriman`, `nama_pengirim`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `status_pengiriman`) VALUES ('24', 'Haris', 'Haris', 'Malang', '15', 'Pickup', 'P2032XM', '2021-04-27', 'Sudah Terkirim');
INSERT INTO `pengiriman` (`id_pengiriman`, `nama_pengirim`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `status_pengiriman`) VALUES ('25', 'Haris', '0256123', 'sdasd', '3', 'hahah', 'P2032XM', '2021-04-28', 'Sudah Terkirim');
INSERT INTO `pengiriman` (`id_pengiriman`, `nama_pengirim`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `status_pengiriman`) VALUES ('28', 'haris', '3241341', 'sdasd', '2', 'perkakas', '12', '2021-04-28', 'Sudah Terkirim');
INSERT INTO `pengiriman` (`id_pengiriman`, `nama_pengirim`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `status_pengiriman`) VALUES ('29', 'Akbar', '0855221133', 'Malang', '100', 'Pickup', 'P2032XM', '2021-04-30', 'Sudah Terkirim');


#
# TABLE STRUCTURE FOR: pengurangan_stockproduksi
#

DROP TABLE IF EXISTS `pengurangan_stockproduksi`;

CREATE TABLE `pengurangan_stockproduksi` (
  `id_penguranganstockproduksi` int(50) NOT NULL AUTO_INCREMENT,
  `id_detailproduksi` int(11) NOT NULL,
  `id_detailsemuabarang` int(50) NOT NULL,
  `jumlah_pengurangan` int(50) NOT NULL,
  PRIMARY KEY (`id_penguranganstockproduksi`),
  KEY `id_detail_semuabarang_idxfk` (`id_detailsemuabarang`),
  KEY `id_detailproduksi_idxfk` (`id_detailproduksi`),
  CONSTRAINT `id_detail_semuabarang_idxfk` FOREIGN KEY (`id_detailsemuabarang`) REFERENCES `detail_semuabarang` (`id_detailsemuabarang`),
  CONSTRAINT `id_detailproduksi_idxfk` FOREIGN KEY (`id_detailproduksi`) REFERENCES `detail_produksi` (`id_detailproduksi`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `pengurangan_stockproduksi` (`id_penguranganstockproduksi`, `id_detailproduksi`, `id_detailsemuabarang`, `jumlah_pengurangan`) VALUES ('4', '5', '7', '20');
INSERT INTO `pengurangan_stockproduksi` (`id_penguranganstockproduksi`, `id_detailproduksi`, `id_detailsemuabarang`, `jumlah_pengurangan`) VALUES ('5', '5', '8', '20');
INSERT INTO `pengurangan_stockproduksi` (`id_penguranganstockproduksi`, `id_detailproduksi`, `id_detailsemuabarang`, `jumlah_pengurangan`) VALUES ('6', '5', '9', '20');


#
# TABLE STRUCTURE FOR: produksi
#

DROP TABLE IF EXISTS `produksi`;

CREATE TABLE `produksi` (
  `id_produksi` int(255) NOT NULL AUTO_INCREMENT,
  `nama_staff` varchar(255) NOT NULL,
  `shift` varchar(255) NOT NULL,
  `jumlah_produksi` int(255) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  PRIMARY KEY (`id_produksi`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

INSERT INTO `produksi` (`id_produksi`, `nama_staff`, `shift`, `jumlah_produksi`, `tanggal`) VALUES ('30', 'Haris', 'shift1', '100', '2021-04-30');
INSERT INTO `produksi` (`id_produksi`, `nama_staff`, `shift`, `jumlah_produksi`, `tanggal`) VALUES ('31', 'Haris', 'shift2', '100', '2021-04-28');
INSERT INTO `produksi` (`id_produksi`, `nama_staff`, `shift`, `jumlah_produksi`, `tanggal`) VALUES ('32', 'Haris', 'shift1', '100', '2021-04-29');
INSERT INTO `produksi` (`id_produksi`, `nama_staff`, `shift`, `jumlah_produksi`, `tanggal`) VALUES ('33', 'Haris', 'shift1', '100', '2021-04-29');
INSERT INTO `produksi` (`id_produksi`, `nama_staff`, `shift`, `jumlah_produksi`, `tanggal`) VALUES ('34', 'Haris2e12ewr', 'shift2', '100', '2021-04-29');
INSERT INTO `produksi` (`id_produksi`, `nama_staff`, `shift`, `jumlah_produksi`, `tanggal`) VALUES ('35', 'zaman', 'shift2', '100', '2021-04-30');


