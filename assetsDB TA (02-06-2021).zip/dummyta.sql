#
# TABLE STRUCTURE FOR: barang
#

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL AUTO_INCREMENT,
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  `total` int(11) NOT NULL,
  PRIMARY KEY (`id_barang`),
  UNIQUE KEY `id_kategori` (`id_kategori`),
  CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`),
  CONSTRAINT `barang_ibfk_2` FOREIGN KEY (`id_barang`) REFERENCES `detail_semuabarang` (`id_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: detail_pengiriman
#

DROP TABLE IF EXISTS `detail_pengiriman`;

CREATE TABLE `detail_pengiriman` (
  `id_detailpengiriman` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengiriman` int(50) NOT NULL,
  `namapengirim` varchar(255) NOT NULL,
  `no_hp` int(255) NOT NULL,
  `jeniskendaraan` varchar(255) NOT NULL,
  `tujuan_pengiriman` varchar(255) NOT NULL,
  `no_kendaraan` varchar(255) NOT NULL,
  `status` enum('Proses Pengiriman','Sudah Terkirim') NOT NULL,
  `jumlah_pengiriman` int(255) NOT NULL,
  `tanggal_masuk` date NOT NULL,
  `tanggal_diterima` date NOT NULL,
  PRIMARY KEY (`id_detailpengiriman`),
  KEY `id_pengiriman` (`id_pengiriman`),
  CONSTRAINT `detail_pengiriman_ibfk_1` FOREIGN KEY (`id_pengiriman`) REFERENCES `pengiriman` (`id_pengiriman`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `detail_pengiriman` (`id_detailpengiriman`, `id_pengiriman`, `namapengirim`, `no_hp`, `jeniskendaraan`, `tujuan_pengiriman`, `no_kendaraan`, `status`, `jumlah_pengiriman`, `tanggal_masuk`, `tanggal_diterima`) VALUES ('5', '29', 'Akbar', '855221133', 'Pickup', 'Malang', 'P2032XM', 'Sudah Terkirim', '100', '2021-04-30', '2021-05-05');
INSERT INTO `detail_pengiriman` (`id_detailpengiriman`, `id_pengiriman`, `namapengirim`, `no_hp`, `jeniskendaraan`, `tujuan_pengiriman`, `no_kendaraan`, `status`, `jumlah_pengiriman`, `tanggal_masuk`, `tanggal_diterima`) VALUES ('6', '30', 'Haris', '256123', 'Pickup', 'Malang', 'P2032XM', 'Sudah Terkirim', '23', '2021-05-13', '2021-05-14');


#
# TABLE STRUCTURE FOR: detail_produksi
#

DROP TABLE IF EXISTS `detail_produksi`;

CREATE TABLE `detail_produksi` (
  `id_detailproduksi` int(50) NOT NULL AUTO_INCREMENT,
  `id_produksi` int(50) NOT NULL,
  `tanggal` date NOT NULL,
  `nama_staff` varchar(50) NOT NULL,
  `shift` varchar(50) NOT NULL,
  PRIMARY KEY (`id_detailproduksi`),
  KEY `id_produk_idxfk` (`id_produksi`),
  CONSTRAINT `id_produk_idxfk` FOREIGN KEY (`id_produksi`) REFERENCES `produksi` (`id_produksi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: detail_semuabarang
#

DROP TABLE IF EXISTS `detail_semuabarang`;

CREATE TABLE `detail_semuabarang` (
  `id_detailsemuabarang` int(50) NOT NULL AUTO_INCREMENT,
  `id_barang` int(11) NOT NULL,
  `tanggal_stockgudang` date NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `stock_pabrik` int(255) NOT NULL,
  PRIMARY KEY (`id_detailsemuabarang`),
  KEY `id_barang` (`id_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `detail_semuabarang` (`id_detailsemuabarang`, `id_barang`, `tanggal_stockgudang`, `nama_barang`, `stock_pabrik`) VALUES ('7', '0', '2021-05-24', 'Botol', '1874');
INSERT INTO `detail_semuabarang` (`id_detailsemuabarang`, `id_barang`, `tanggal_stockgudang`, `nama_barang`, `stock_pabrik`) VALUES ('8', '0', '2021-05-24', 'Kardus', '10');
INSERT INTO `detail_semuabarang` (`id_detailsemuabarang`, `id_barang`, `tanggal_stockgudang`, `nama_barang`, `stock_pabrik`) VALUES ('9', '0', '2021-05-23', 'Isolasi', '52');
INSERT INTO `detail_semuabarang` (`id_detailsemuabarang`, `id_barang`, `tanggal_stockgudang`, `nama_barang`, `stock_pabrik`) VALUES ('10', '0', '2021-05-02', 'AIR', '33');
INSERT INTO `detail_semuabarang` (`id_detailsemuabarang`, `id_barang`, `tanggal_stockgudang`, `nama_barang`, `stock_pabrik`) VALUES ('11', '0', '2021-05-15', 'Stiker Hologram', '19');
INSERT INTO `detail_semuabarang` (`id_detailsemuabarang`, `id_barang`, `tanggal_stockgudang`, `nama_barang`, `stock_pabrik`) VALUES ('12', '0', '2021-05-15', 'Tutup Botol', '39');


#
# TABLE STRUCTURE FOR: detail_stockproduksi
#

DROP TABLE IF EXISTS `detail_stockproduksi`;

CREATE TABLE `detail_stockproduksi` (
  `id_detailstockproduksi` int(255) NOT NULL AUTO_INCREMENT,
  `id_produksi` int(50) NOT NULL,
  `tanggal_stockproduksi` date NOT NULL,
  `stock_produksi` int(255) NOT NULL,
  PRIMARY KEY (`id_detailstockproduksi`),
  KEY `id_produksi` (`id_produksi`),
  CONSTRAINT `detail_stockproduksi_ibfk_1` FOREIGN KEY (`id_detailstockproduksi`) REFERENCES `pengiriman` (`id_detailstockproduksi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: kategori
#

DROP TABLE IF EXISTS `kategori`;

CREATE TABLE `kategori` (
  `id_kategori` int(50) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(255) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES ('7', 'Botol');
INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES ('10', 'Kardus');
INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES ('11', 'Tutup Botol');
INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES ('12', 'Isolasi');
INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES ('14', 'Stiker Hologram');


#
# TABLE STRUCTURE FOR: login
#

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `level` enum('admin','Staff Produksi','Staff Pengiriman','Staff Gudang') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `login` (`id`, `nama`, `username`, `password`, `level`) VALUES ('17', 'haris46', 'admin', 'admin', 'admin');
INSERT INTO `login` (`id`, `nama`, `username`, `password`, `level`) VALUES ('24', 'produksi', 'produksi', '1234', 'Staff Produksi');
INSERT INTO `login` (`id`, `nama`, `username`, `password`, `level`) VALUES ('25', 'pengiriman', 'pengiriman', '1234', 'Staff Pengiriman');
INSERT INTO `login` (`id`, `nama`, `username`, `password`, `level`) VALUES ('26', 'Gudang', 'gudang', '1234', 'Staff Gudang');


#
# TABLE STRUCTURE FOR: pengiriman
#

DROP TABLE IF EXISTS `pengiriman`;

CREATE TABLE `pengiriman` (
  `id_pengiriman` int(255) NOT NULL AUTO_INCREMENT,
  `id_detailstockproduksi` int(50) NOT NULL,
  `nama_pengirim` varchar(255) NOT NULL,
  `nomorhp` varchar(255) NOT NULL,
  `tujuan` varchar(255) NOT NULL,
  `jumlah` varchar(255) NOT NULL,
  `jenis_kendaraan` varchar(255) NOT NULL,
  `nomor_kendaraan` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `status_pengiriman` enum('Proses Pengiriman','Sudah Terkirim') NOT NULL,
  PRIMARY KEY (`id_pengiriman`),
  KEY `id_detailstockproduksi` (`id_detailstockproduksi`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `pengiriman` (`id_pengiriman`, `id_detailstockproduksi`, `nama_pengirim`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `status_pengiriman`) VALUES ('1', '0', 'haris', '0855221133', 'Malang', '23', 'Pickup', 'P2032XM', '2021-06-02', 'Proses Pengiriman');


#
# TABLE STRUCTURE FOR: pengurangan_stockproduksi
#

DROP TABLE IF EXISTS `pengurangan_stockproduksi`;

CREATE TABLE `pengurangan_stockproduksi` (
  `id_penguranganstockproduksi` int(50) NOT NULL AUTO_INCREMENT,
  `id_detailproduksi` int(11) NOT NULL,
  `id_detailsemuabarang` int(50) NOT NULL,
  `jumlah_pengurangan` int(50) NOT NULL,
  PRIMARY KEY (`id_penguranganstockproduksi`),
  KEY `id_detail_semuabarang_idxfk` (`id_detailsemuabarang`),
  KEY `id_detailproduksi_idxfk` (`id_detailproduksi`),
  CONSTRAINT `id_detail_semuabarang_idxfk` FOREIGN KEY (`id_detailsemuabarang`) REFERENCES `detail_semuabarang` (`id_detailsemuabarang`),
  CONSTRAINT `id_detailproduksi_idxfk` FOREIGN KEY (`id_detailproduksi`) REFERENCES `detail_produksi` (`id_detailproduksi`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `pengurangan_stockproduksi` (`id_penguranganstockproduksi`, `id_detailproduksi`, `id_detailsemuabarang`, `jumlah_pengurangan`) VALUES ('7', '7', '7', '1');
INSERT INTO `pengurangan_stockproduksi` (`id_penguranganstockproduksi`, `id_detailproduksi`, `id_detailsemuabarang`, `jumlah_pengurangan`) VALUES ('9', '7', '9', '1');
INSERT INTO `pengurangan_stockproduksi` (`id_penguranganstockproduksi`, `id_detailproduksi`, `id_detailsemuabarang`, `jumlah_pengurangan`) VALUES ('10', '7', '11', '1');
INSERT INTO `pengurangan_stockproduksi` (`id_penguranganstockproduksi`, `id_detailproduksi`, `id_detailsemuabarang`, `jumlah_pengurangan`) VALUES ('11', '7', '12', '1');
INSERT INTO `pengurangan_stockproduksi` (`id_penguranganstockproduksi`, `id_detailproduksi`, `id_detailsemuabarang`, `jumlah_pengurangan`) VALUES ('12', '7', '8', '30');
INSERT INTO `pengurangan_stockproduksi` (`id_penguranganstockproduksi`, `id_detailproduksi`, `id_detailsemuabarang`, `jumlah_pengurangan`) VALUES ('13', '8', '7', '200');
INSERT INTO `pengurangan_stockproduksi` (`id_penguranganstockproduksi`, `id_detailproduksi`, `id_detailsemuabarang`, `jumlah_pengurangan`) VALUES ('14', '8', '8', '10');


#
# TABLE STRUCTURE FOR: produksi
#

DROP TABLE IF EXISTS `produksi`;

CREATE TABLE `produksi` (
  `id_produksi` int(255) NOT NULL AUTO_INCREMENT,
  `nama_staff` varchar(255) NOT NULL,
  `shift` varchar(255) NOT NULL,
  `jumlah_produksi` int(255) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  PRIMARY KEY (`id_produksi`),
  CONSTRAINT `produksi_ibfk_1` FOREIGN KEY (`id_produksi`) REFERENCES `detail_stockproduksi` (`id_produksi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

